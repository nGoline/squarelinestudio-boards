#ifndef MY_ATOMIC_H
#define MY_ATOMIC_H

#warning "Custom atomic.h is being used"
#include "stdatomic.h"

#endif // MY_ATOMIC_H