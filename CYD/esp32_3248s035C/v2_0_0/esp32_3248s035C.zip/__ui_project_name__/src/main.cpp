#include <Arduino.h>
#include <esp32_smartdisplay.h>
#include <ui/ui.h>

static auto lv_last_tick = millis();
static uint32_t delayLvgl;

void setup()
{
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  log_i("Board: %s", BOARD_NAME);
  log_i("CPU: %s rev%d, CPU Freq: %d Mhz, %d core(s)", ESP.getChipModel(), ESP.getChipRevision(), getCpuFrequencyMhz(), ESP.getChipCores());
  log_i("Free heap: %d bytes", ESP.getFreeHeap());
  log_i("Free PSRAM: %d bytes", ESP.getPsramSize());
  log_i("SDK version: %s", ESP.getSdkVersion());

  // Initialize SmartDisplay
  smartdisplay_init();

  // Get Default Display
  auto disp = lv_disp_get_default();

  // Set Rotation as needed
  lv_display_set_rotation(disp, LV_DISPLAY_ROTATION_90);

  // Initialiez UI
  ui_init();
}

void loop()
{
  // Update ticks
  auto const now = millis();
  lv_tick_inc(now - lv_last_tick);
  lv_last_tick = now;

  // Update the UI
  delayLvgl = lv_timer_handler();
  vTaskDelay(delayLvgl + 1 / portTICK_PERIOD_MS);
}