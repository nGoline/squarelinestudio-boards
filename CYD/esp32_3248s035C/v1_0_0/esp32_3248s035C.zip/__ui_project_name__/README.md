# __UI_PROJECT_NAME__

This project uses [esp32-smartdisplay](https://github.com/rzeldent/esp32-smartdisplay).

## Board

The board used is esp32-3248S035C and can be found [here](https://www.aliexpress.com/item/1005004632953455.html).